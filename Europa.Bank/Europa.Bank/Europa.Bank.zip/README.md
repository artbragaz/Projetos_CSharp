/\* TESTES A SEREM FEITOS:

- Cadastrar um cliente
- Cadastrar uma conta 101PHJ tem 100 T43ANJ|
- Logar com uma conta
- Tentar cadastrar cliente com mesmo CPF
- Tentar usar valores errados de CPF
- Verificar números de conta
- Depositar
- Sacar
- Transferir
- Checar Saldo
- Efetuar transações com valor negativo
-
- \*/

// Bem vindo ao banco europa
// A[1] - voce deseja cadatrar um cliente? (Nome, CPF) -> B
// A[2] - voce deseja cadastrar uma nova conta? (CPF) -> B
// A[3] - voce deseja logar com uma conta existente? (numero) -> B
// A[4] - Sair
//
// B[1] - Depositar (valor)
// B[2] - Sacar (valor)
// B[3] - Consultar (void)
// B[4] - Transferir (número,valor)
// B[5] - Sair -> A
